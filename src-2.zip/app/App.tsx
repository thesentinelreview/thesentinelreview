import { useState, useEffect } from 'react';
import { AlertCircle } from 'lucide-react';
import { Header } from './components/Header';
import { SensorStrip } from './components/SensorStrip';
import { DashboardMap } from './components/DashboardMap';
import { AtAGlance } from './components/AtAGlance';
import { IntensityChart } from './components/IntensityChart';
import { ActiveAlerts } from './components/ActiveAlerts';
import { TopSources } from './components/TopSources';
import { DailyBriefing } from './components/DailyBriefing';
import { ThreatAxes } from './components/ThreatAxes';
import { SourceFeed } from './components/SourceFeed';
import { conflictEvents, topSources, weeklyStats, dailyBriefing } from './data/mockData';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'sources' | 'methodology'>('dashboard');

  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.slice(1);
      if (hash === 'sources' || hash === 'methodology') {
        setCurrentPage(hash);
      } else {
        setCurrentPage('dashboard');
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);
  const totalEvents = weeklyStats[weeklyStats.length - 1].eventCount;
  const strikeCount = weeklyStats[weeklyStats.length - 1].strikeCount;
  const verifiedCount = conflictEvents.filter(e => e.confidence === 'verified').length;
  const verifiedPercentage = Math.round((verifiedCount / conflictEvents.length) * 100);

  const currentDayEvents = weeklyStats[weeklyStats.length - 1].eventCount;
  const previousWeekAvg = weeklyStats.slice(0, -1).reduce((sum, day) => sum + day.eventCount, 0) / (weeklyStats.length - 1);
  const weeklyTrend = Math.round(((currentDayEvents - previousWeekAvg) / previousWeekAvg) * 100);

  if (currentPage === 'sources') {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100">
        <Header />
        <SensorStrip />
        <SourceFeed />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header />
      <SensorStrip />

      <main className="p-6 max-w-[1800px] mx-auto">
        <div className="grid grid-cols-12 gap-6">
          {/* Map - Full width top section */}
          <div className="col-span-12 h-[550px]">
            <DashboardMap events={conflictEvents} />
          </div>

          {/* Left Column - Stats and Charts */}
          <div className="col-span-12 lg:col-span-3 space-y-6">
            <AtAGlance
              totalEvents={totalEvents}
              strikeCount={strikeCount}
              verifiedPercentage={verifiedPercentage}
              weeklyTrend={weeklyTrend}
            />
            <IntensityChart data={weeklyStats} />
          </div>

          {/* Middle Column - Active Alerts */}
          <div className="col-span-12 lg:col-span-6">
            <ActiveAlerts events={conflictEvents} />
          </div>

          {/* Right Column - Threat Axes and Sources */}
          <div className="col-span-12 lg:col-span-3 space-y-6">
            <ThreatAxes timeWindow="24H" />
            <TopSources sources={topSources} />
          </div>

          {/* Daily Briefing - Full width bottom */}
          <div className="col-span-12">
            <DailyBriefing briefing={dailyBriefing} />
          </div>
        </div>

        {/* Footer disclaimer */}
        <footer className="mt-12 pt-8 border-t border-slate-800/50">
          <div className="bg-amber-500/5 border border-amber-500/20 rounded-lg p-6 mb-6">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-amber-500/10 rounded-lg border border-amber-500/20 flex-shrink-0">
                <AlertCircle className="w-5 h-5 text-amber-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-amber-400 mb-1 uppercase tracking-wider">Disclaimer</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  This platform is a <strong className="text-slate-300">situational awareness tool only</strong>.
                  It does not support military targeting or operational planning. Events are algorithmically extracted and
                  scored; high-impact events require human editorial review before publication. All data is derived from
                  open-source intelligence and may contain inaccuracies.
                </p>
              </div>
            </div>
          </div>
          <div className="text-center text-xs text-slate-600">
            <p>The Sentinel Review — Washington, D.C.</p>
            <p className="mt-1">contact@thesentinelreview.com • thesentinelreview.com</p>
          </div>
        </footer>
      </main>
    </div>
  );
}