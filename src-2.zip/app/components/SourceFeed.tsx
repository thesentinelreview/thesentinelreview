import { useState } from 'react';
import { ArrowRight, Radio, Eye } from 'lucide-react';

interface SourcePost {
  id: string;
  source: string;
  platform: 'RSS' | 'X' | 'Telegram';
  tier: 1 | 2 | 3;
  timestamp: string;
  content: string;
  originalLanguage?: string;
  verified: boolean;
}

const mockPosts: SourcePost[] = [
  {
    id: '1',
    source: 'Kyiv Independent',
    platform: 'RSS',
    tier: 1,
    timestamp: '20 min',
    content: "Explosions rock Kyiv in Russian strikes amid intelligence warnings of mass attack Russia launched a large-scale aerial attack against Ukraine overnight on June 2, targeting Kyiv and cities across the country with missiles and drone fire.",
    verified: false
  },
  {
    id: '2',
    source: 'Nexus',
    platform: 'RSS',
    tier: 2,
    timestamp: '1h ago',
    content: "Kyiv braces for 'massive' Russian strike after Putin says Ukrainian attack on Sevastola dorm changed war's 'nature' Russian President Vladimir Putin convened a meeting to discuss the investigation into Ukraine's attack on a college building in the city of Sevastola in the occupied Luhansk region.",
    verified: false
  },
  {
    id: '3',
    source: 'DeepStateUA',
    platform: 'Telegram',
    tier: 2,
    timestamp: '3h ago',
    content: 'War update: 178 clashes on front lines, 30 Russian assaults repelled near Pokrovsk A total of 178 combat engagements were recorded along the frontlines as of 22:00 on Monday, with the heaviest fighting taking place in the Pokrovsk sector, where Ukrainian forces eliminated 30 Russian assaults.',
    verified: false
  }
];

export function SourceFeed() {
  const [showOriginal, setShowOriginal] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Header Section */}
      <div className="border-b border-slate-800 bg-slate-950">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-cyan-500/10 rounded-lg border border-cyan-500/20">
              <Radio className="w-6 h-6 text-cyan-400" />
            </div>
            <h1 className="text-3xl font-bold text-white uppercase tracking-tight">
              Source Feed
            </h1>
          </div>

          <div className="flex items-center gap-6 text-sm mb-6">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
              <span className="text-emerald-400 font-semibold">VERIFIED RSS</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-lg">
              <div className="w-2 h-2 rounded-full bg-blue-400"></div>
              <span className="text-blue-400 font-semibold">NEXT INGEST</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-800 border border-slate-700 rounded-lg">
              <span className="text-slate-400 text-xs uppercase tracking-wider">Theater:</span>
              <span className="text-slate-200 font-semibold">Ukraine / Luhansk Oblasts</span>
            </div>
          </div>

          <button className="flex items-center gap-2 px-6 py-3 bg-slate-800 hover:bg-slate-700 border border-slate-600 hover:border-slate-500 rounded-lg transition-all group">
            <span className="text-slate-200 font-semibold uppercase tracking-wider">Load Older Posts</span>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-slate-300 group-hover:translate-x-1 transition-all" />
          </button>
        </div>
      </div>

      {/* Disclaimer */}
      <div className="border-b border-slate-800/50 bg-slate-900/30">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <p className="text-xs text-slate-500 leading-relaxed font-mono">
            Raw, unverified source posts — not yet corroborated or geolocated by Sentinel. AI-translated where available;
            original-language text via the "Show original" toggle on each card. Sourced from open-source reporting. Not for
            operational use.
          </p>
        </div>
      </div>

      {/* Posts Feed */}
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-6">
          <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Yesterday</h2>
        </div>

        <div className="space-y-4">
          {mockPosts.map((post) => (
            <div
              key={post.id}
              className="bg-slate-900/50 border border-slate-800 hover:border-slate-700 rounded-lg p-5 transition-all group"
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <span className="text-base font-bold text-slate-100">{post.source}</span>
                  <span className="px-2 py-0.5 bg-blue-500/20 text-blue-400 border border-blue-500/30 rounded text-xs font-semibold uppercase tracking-wider">
                    {post.platform}
                  </span>
                  <span className="px-2 py-0.5 bg-slate-700/50 text-slate-400 border border-slate-600 rounded text-xs font-semibold">
                    TIER {post.tier}
                  </span>
                </div>
                <span className="text-xs text-slate-500 font-mono">{post.timestamp}</span>
              </div>

              <p className="text-sm text-slate-300 leading-relaxed mb-4">
                {post.content}
              </p>

              <div className="flex items-center justify-between pt-3 border-t border-slate-800">
                <div className="flex items-center gap-3">
                  <button className="text-xs text-slate-400 hover:text-slate-300 underline decoration-dotted underline-offset-2 transition-colors">
                    view source →
                  </button>
                  {post.originalLanguage && (
                    <button
                      onClick={() => setShowOriginal(showOriginal === post.id ? null : post.id)}
                      className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-xs text-slate-400 hover:text-slate-300 transition-colors"
                    >
                      <Eye className="w-3 h-3" />
                      <span>Show original</span>
                    </button>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {!post.verified && (
                    <span className="px-2 py-1 bg-slate-800/50 text-slate-500 border border-slate-700 rounded text-[10px] font-bold uppercase tracking-wider">
                      Unverified
                    </span>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
