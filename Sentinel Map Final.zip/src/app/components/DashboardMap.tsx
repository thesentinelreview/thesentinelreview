import { useEffect, useRef } from 'react';
import maplibregl from 'maplibre-gl';
import { ConflictEvent } from '../data/mockData';
import { MapLegend } from './MapLegend';
import 'maplibre-gl/dist/maplibre-gl.css';

interface DashboardMapProps {
  events: ConflictEvent[];
  onEventClick?: (event: ConflictEvent) => void;
}

const eventTypeColors = {
  strike: '#ef4444',
  clash: '#f59e0b',
  movement: '#3b82f6'
};

const eventTypeIcons = {
  strike: '🎯',
  clash: '⚔️',
  movement: '📈'
};

export function DashboardMap({ events, onEventClick }: DashboardMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<maplibregl.Map | null>(null);

  useEffect(() => {
    if (!mapContainer.current || map.current) return;

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: 'https://basemaps.cartocdn.com/gl/dark-matter-gl-style/style.json',
      center: [37.5, 48.5],
      zoom: 6.5
    });

    map.current.addControl(new maplibregl.NavigationControl(), 'top-right');

    return () => {
      map.current?.remove();
      map.current = null;
    };
  }, []);

  useEffect(() => {
    if (!map.current) return;

    // Remove existing markers
    const existingMarkers = document.querySelectorAll('.maplibregl-marker');
    existingMarkers.forEach(marker => marker.remove());

    // Add new markers
    events.forEach((event) => {
      const el = document.createElement('div');
      el.className = 'event-marker';
      el.style.cssText = `
        width: 32px;
        height: 32px;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        background-color: ${eventTypeColors[event.type]};
        opacity: ${event.confidence === 'verified' ? 1 : event.confidence === 'partial' ? 0.7 : 0.5};
        transition: transform 0.2s;
        font-size: 16px;
      `;
      el.innerHTML = eventTypeIcons[event.type];
      el.title = `${event.type} - ${event.confidence}`;

      el.addEventListener('mouseenter', () => {
        el.style.transform = 'scale(1.1)';
      });

      el.addEventListener('mouseleave', () => {
        el.style.transform = 'scale(1)';
      });

      el.addEventListener('click', () => {
        onEventClick?.(event);
      });

      new maplibregl.Marker({ element: el })
        .setLngLat([event.coordinates[0], event.coordinates[1]])
        .addTo(map.current!);
    });
  }, [events, onEventClick]);

  return (
    <div className="w-full h-full rounded-lg overflow-hidden border border-slate-700 relative">
      <div ref={mapContainer} className="w-full h-full" />
      <MapLegend />
    </div>
  );
}
