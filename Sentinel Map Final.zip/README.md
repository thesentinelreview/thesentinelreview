
  # Sentinel Map Final

  This is a code bundle for Sentinel Map Final. The original project is available at https://www.figma.com/design/8Std5iPT5yBLtaFPlTxPcc/Sentinel-Map-Final.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  