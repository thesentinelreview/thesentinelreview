import { Crosshair } from 'lucide-react';
import { IntensityChart } from './IntensityChart';
import { DailyStats } from '../data/mockData';

interface ThreatAxis {
  name: string;
  count: number;
  percentage: number;
  color: string;
}

interface ThreatAxesProps {
  timeWindow?: string;
  weeklyStats: DailyStats[];
}

const threatData: ThreatAxis[] = [
  { name: 'Drone', count: 22, percentage: 67, color: 'from-orange-500 to-red-500' },
  { name: 'Infantry', count: 5, percentage: 15, color: 'from-cyan-500 to-teal-500' },
  { name: 'Artillery', count: 3, percentage: 9, color: 'from-emerald-500 to-green-500' },
  { name: 'Other', count: 2, percentage: 6, color: 'from-slate-500 to-slate-600' },
  { name: 'Missile', count: 1, percentage: 3, color: 'from-purple-500 to-pink-500' }
];

export function ThreatAxes({ timeWindow = '24H', weeklyStats }: ThreatAxesProps) {
  const totalEvents = threatData.reduce((sum, item) => sum + item.count, 0);

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <div className="p-1.5 bg-red-500/10 rounded-lg border border-red-500/20">
                <Crosshair className="w-4 h-4 text-red-400" />
              </div>
              <h2 className="text-lg font-bold text-slate-100 uppercase tracking-wider">Threat Axes</h2>
            </div>
            <div className="flex items-center gap-2 text-xs ml-8">
              <span className="text-emerald-400 font-semibold uppercase tracking-wider">Sectors</span>
              <span className="text-slate-600">•</span>
              <span className="text-cyan-400 font-semibold uppercase tracking-wider">Axes</span>
            </div>
          </div>
          <div className="px-3 py-1.5 bg-slate-800/50 border border-slate-700 rounded-lg">
            <span className="text-xs text-slate-400 font-mono font-semibold">{timeWindow} WINDOW</span>
          </div>
        </div>

        <div className="space-y-4">
          {threatData.map((threat, index) => (
            <div key={threat.name} className="group">
              <div className="flex items-center justify-between mb-2">
                <span className="text-base font-bold text-slate-100">{threat.name}</span>
                <span className="text-2xl font-bold text-slate-100">{threat.count}</span>
              </div>

              <div className="relative h-2 bg-slate-800 rounded-full overflow-hidden mb-1">
                <div
                  className={`absolute inset-y-0 left-0 bg-gradient-to-r ${threat.color} transition-all duration-500 ease-out`}
                  style={{ width: `${threat.percentage}%` }}
                >
                  <div className="absolute inset-0 bg-white/10"></div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-xs text-slate-500 font-medium">
                  {threat.percentage}% of classified
                </span>
                <span className="text-[10px] text-slate-600 font-mono">
                  {threat.count}/{totalEvents}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-5 border-t border-slate-800">
          <div className="flex items-center justify-between text-xs">
            <span className="text-slate-500">Total classified threats</span>
            <span className="text-slate-400 font-bold">{totalEvents} events</span>
          </div>
        </div>
      </div>

      <IntensityChart data={weeklyStats} />
    </div>
  );
}
