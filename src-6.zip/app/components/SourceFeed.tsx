import { useState } from 'react';
import { Database, ChevronDown } from 'lucide-react';

interface SourceEntry {
  id: string;
  name: string;
  platforms: ('RSS' | 'X' | 'Telegram' | 'Bluesky' | 'GDELT')[];
  tier: 1 | 2 | 3;
  partner?: boolean;
  description: string;
  posts: number;
  events: number;
  reliability: number; // 0–100
  lastSeen: string;
}

const sources: SourceEntry[] = [
  {
    id: '1',
    name: 'Tautar News English',
    platforms: ['Telegram'],
    tier: 1,
    partner: true,
    description: 'English-language Telegram channel covering confirmed conflict events in eastern Ukraine with geolocated footage. Maintains strict editorial standards; disputed posts are flagged within the channel itself.',
    posts: 20,
    events: 212,
    reliability: 94,
    lastSeen: '4 min ago'
  },
  {
    id: '2',
    name: 'Nextstep',
    platforms: ['RSS'],
    tier: 1,
    partner: true,
    description: 'Automated wire aggregator for Ukrainian defense ministry statements and official oblasts situation reports. Machine-translated from Ukrainian; original text available on source.',
    posts: 12,
    events: 146,
    reliability: 88,
    lastSeen: '11 min ago'
  },
  {
    id: '3',
    name: 'TSS (monitor wiki)',
    platforms: ['RSS', 'X'],
    tier: 2,
    description: 'Crowdsourced front-line monitoring wiki. Aggregates community-submitted geolocations with editorial review. High volume; accuracy varies by contributor tier.',
    posts: 2,
    events: 141,
    reliability: 71,
    lastSeen: '32 min ago'
  },
  {
    id: '4',
    name: 'InfoFlex Service',
    platforms: ['RSS', 'X'],
    tier: 2,
    description: 'Ukrainian military analysis blog with documented geolocations. Focuses on equipment losses and confirmed strike damage. Some posts are speculative and labeled accordingly.',
    posts: 8,
    events: 73,
    reliability: 76,
    lastSeen: '1h ago'
  },
  {
    id: '5',
    name: 'Tov Report',
    platforms: ['Telegram'],
    tier: 3,
    description: 'Anonymous Telegram channel reporting from Donetsk sector. High frequency; low independent corroboration. Used for signal detection only — never cited alone.',
    posts: 31,
    events: 58,
    reliability: 42,
    lastSeen: '2h ago'
  },
  {
    id: '6',
    name: 'Nexus',
    platforms: ['RSS'],
    tier: 2,
    description: 'Regional news aggregator covering eastern European security events. Sourced from multiple wire feeds with editorial curation. Generally reliable for situational context.',
    posts: 4,
    events: 44,
    reliability: 79,
    lastSeen: '2h ago'
  },
  {
    id: '7',
    name: 'Kyiv Independent',
    platforms: ['RSS'],
    tier: 1,
    description: 'English-language Ukrainian news outlet with named reporters and formal correction policy. One of the primary Tier 1 sources for Sentinel. Event reports are wire-quality.',
    posts: 4,
    events: 43,
    reliability: 91,
    lastSeen: '3h ago'
  },
  {
    id: '8',
    name: 'GDELT',
    platforms: ['GDELT'],
    tier: 1,
    description: 'Global Database of Events, Language, and Tone. Machine-processed news corpus with geolocation and tone scoring. Used for cluster detection and corroboration signals, not primary sourcing.',
    posts: 4,
    events: 42,
    reliability: 85,
    lastSeen: '6h ago'
  }
];

const PLATFORM_STYLES: Record<string, string> = {
  RSS:      'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
  X:        'text-sky-400 bg-sky-500/10 border-sky-500/30',
  Telegram: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
  Bluesky:  'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
  GDELT:    'text-amber-400 bg-amber-500/10 border-amber-500/30',
};

const TIER_STYLES: Record<number, string> = {
  1: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
  2: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
  3: 'text-slate-400 bg-slate-700/30 border-slate-600/40',
};

function ReliabilityBar({ value }: { value: number }) {
  const color = value >= 80 ? 'bg-emerald-500' : value >= 60 ? 'bg-amber-500' : 'bg-red-500';
  return (
    <div className="w-20 h-1.5 bg-slate-800 rounded-full overflow-hidden">
      <div className={`h-full rounded-full ${color}`} style={{ width: `${value}%` }} />
    </div>
  );
}

type TierFilter = 'all' | '1' | '2' | '3';
type PlatformFilter = 'all' | 'RSS' | 'X' | 'Telegram' | 'GDELT' | 'Bluesky';
type SortKey = 'posts' | 'events' | 'reliability' | 'name';

export function SourceFeed() {
  const [tierFilter, setTierFilter] = useState<TierFilter>('all');
  const [platformFilter, setPlatformFilter] = useState<PlatformFilter>('all');
  const [sortBy, setSortBy] = useState<SortKey>('events');

  const filtered = sources
    .filter(s => tierFilter === 'all' || s.tier === Number(tierFilter))
    .filter(s => platformFilter === 'all' || s.platforms.includes(platformFilter as any))
    .sort((a, b) => {
      if (sortBy === 'name') return a.name.localeCompare(b.name);
      if (sortBy === 'posts') return b.posts - a.posts;
      if (sortBy === 'reliability') return b.reliability - a.reliability;
      return b.events - a.events;
    });

  return (
    <div className="p-6 max-w-[1800px] mx-auto">

      {/* Page header */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl mb-6">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-1.5 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <Database className="w-4 h-4 text-blue-400" />
              </div>
              <h2 className="text-lg font-bold text-slate-100">Source Reliability</h2>
            </div>
            <p className="text-xs text-slate-500 uppercase tracking-widest font-semibold">
              All tiers &nbsp;·&nbsp; All platforms &nbsp;·&nbsp; {sources.length} sources indexed
            </p>
          </div>
          <div className="text-xs text-slate-600 font-mono text-right">
            <div>2026-06-03 / 2026-06-04</div>
            <div className="text-slate-700 mt-0.5">Rolling 24h window</div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 mb-4 flex-wrap">
        {/* Tier filter */}
        <div className="flex items-center gap-1">
          {(['all', '1', '2', '3'] as TierFilter[]).map(t => (
            <button
              key={t}
              onClick={() => setTierFilter(t)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider border transition-all ${
                tierFilter === t
                  ? 'bg-slate-700 border-slate-500 text-slate-100'
                  : 'bg-slate-900 border-slate-700 text-slate-500 hover:text-slate-300 hover:border-slate-600'
              }`}
            >
              {t === 'all' ? 'All Tiers' : `Tier ${t}`}
            </button>
          ))}
        </div>

        <div className="w-px h-5 bg-slate-800" />

        {/* Platform filter */}
        <div className="flex items-center gap-1">
          {(['all', 'RSS', 'X', 'Telegram', 'GDELT'] as PlatformFilter[]).map(p => (
            <button
              key={p}
              onClick={() => setPlatformFilter(p)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider border transition-all ${
                platformFilter === p
                  ? 'bg-slate-700 border-slate-500 text-slate-100'
                  : 'bg-slate-900 border-slate-700 text-slate-500 hover:text-slate-300 hover:border-slate-600'
              }`}
            >
              {p === 'all' ? 'All Platforms' : p}
            </button>
          ))}
        </div>

        <div className="ml-auto flex items-center gap-2">
          <span className="text-xs text-slate-600 uppercase tracking-wider">Sort by</span>
          <div className="relative">
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as SortKey)}
              className="appearance-none bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 pr-7 text-xs text-slate-300 font-semibold uppercase tracking-wider focus:outline-none focus:border-slate-500 cursor-pointer"
            >
              <option value="events">Events</option>
              <option value="posts">Posts</option>
              <option value="reliability">Reliability</option>
              <option value="name">Name</option>
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3 h-3 text-slate-500 pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl shadow-xl overflow-hidden">
        {/* Column headers */}
        <div className="grid grid-cols-[2fr_3fr_80px_80px_100px_100px] gap-4 px-6 py-3 border-b border-slate-700/60 bg-slate-900/60">
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Source</span>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Description</span>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Posts</span>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Events</span>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Reliability</span>
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Last seen</span>
        </div>

        <div className="divide-y divide-slate-800/60">
          {filtered.map(source => (
            <div
              key={source.id}
              className="grid grid-cols-[2fr_3fr_80px_80px_100px_100px] gap-4 px-6 py-4 hover:bg-slate-800/30 transition-colors items-center group"
            >
              {/* Source name + badges */}
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap mb-1.5">
                  <span className="text-sm font-bold text-slate-100 truncate">{source.name}</span>
                  {source.partner && (
                    <span className="px-1.5 py-0.5 bg-red-500/15 border border-red-500/30 rounded text-[9px] font-bold text-red-400 uppercase tracking-wider shrink-0">
                      Partner
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {source.platforms.map(p => (
                    <span key={p} className={`px-1.5 py-0.5 border rounded text-[9px] font-bold uppercase tracking-wider ${PLATFORM_STYLES[p]}`}>
                      {p}
                    </span>
                  ))}
                  <span className={`px-1.5 py-0.5 border rounded text-[9px] font-bold uppercase tracking-wider ${TIER_STYLES[source.tier]}`}>
                    Tier {source.tier}
                  </span>
                </div>
              </div>

              {/* Description */}
              <p className="text-xs text-slate-400 leading-relaxed line-clamp-2">{source.description}</p>

              {/* Posts */}
              <span className="text-sm font-bold text-slate-200 text-right tabular-nums">{source.posts}</span>

              {/* Events */}
              <span className="text-sm font-bold text-slate-200 text-right tabular-nums">{source.events}</span>

              {/* Reliability bar + score */}
              <div className="flex flex-col gap-1.5">
                <ReliabilityBar value={source.reliability} />
                <span className="text-[10px] text-slate-500 font-mono">{source.reliability}%</span>
              </div>

              {/* Last seen */}
              <span className="text-xs text-slate-500 font-mono text-right">{source.lastSeen}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4 text-xs text-slate-700 text-center font-mono uppercase tracking-widest">
        {filtered.length} of {sources.length} sources · reliability scored over rolling 30-day window
      </div>
    </div>
  );
}
