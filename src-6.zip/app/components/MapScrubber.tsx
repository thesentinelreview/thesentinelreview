import { useState } from 'react';
import { Play, Pause, SkipBack, SkipForward } from 'lucide-react';

interface MapScrubberProps {
  onTimeChange?: (time: number) => void;
}

export function MapScrubber({ onTimeChange }: MapScrubberProps) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentPosition, setCurrentPosition] = useState(100); // percentage (100 = NOW)

  const timeLabels = ['-24h', '-19h', '-14h', '-10h', '-5h', 'NOW'];

  const getCurrentTime = () => {
    const now = new Date();
    return now.toLocaleTimeString('en-US', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      timeZone: 'UTC'
    });
  };

  const handleScrubberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Number(e.target.value);
    setCurrentPosition(value);
    onTimeChange?.(value);
  };

  const togglePlayback = () => {
    setIsPlaying(!isPlaying);
  };

  return (
    <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-[90%] max-w-6xl">
      <div className="bg-slate-950/95 border border-slate-700 rounded-xl backdrop-blur-lg shadow-2xl overflow-hidden">
        <div className="flex items-center gap-6 px-6 py-3">
          {/* Playback Controls */}
          <div className="flex items-center gap-3">
            <div className="text-xs font-bold text-amber-500/80 uppercase tracking-widest mr-2">
              Playback
            </div>
            <button
              className="p-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded transition-colors"
              onClick={() => setCurrentPosition(Math.max(0, currentPosition - 10))}
            >
              <SkipBack className="w-3.5 h-3.5 text-slate-300" />
            </button>
            <button
              className="p-2 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded transition-colors"
              onClick={togglePlayback}
            >
              {isPlaying ? (
                <Pause className="w-4 h-4 text-emerald-400" fill="currentColor" />
              ) : (
                <Play className="w-4 h-4 text-emerald-400" fill="currentColor" />
              )}
            </button>
            <button
              className="p-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 rounded transition-colors"
              onClick={() => setCurrentPosition(Math.min(100, currentPosition + 10))}
            >
              <SkipForward className="w-3.5 h-3.5 text-slate-300" />
            </button>
          </div>

          {/* Timeline Scrubber */}
          <div className="flex-1">
            <div className="relative">
              {/* Time Labels */}
              <div className="flex justify-between mb-2 px-1">
                {timeLabels.map((label, index) => (
                  <span
                    key={label}
                    className={`text-xs font-mono ${
                      index === timeLabels.length - 1
                        ? 'text-red-400 font-bold'
                        : 'text-slate-500'
                    }`}
                  >
                    {label}
                  </span>
                ))}
              </div>

              {/* Scrubber Track */}
              <div className="relative h-2 bg-slate-800 rounded-full overflow-hidden">
                {/* Progress Bar */}
                <div
                  className="absolute inset-y-0 left-0 bg-gradient-to-r from-cyan-500 to-blue-500"
                  style={{ width: `${currentPosition}%` }}
                >
                  <div className="absolute inset-0 bg-white/10"></div>
                </div>

                {/* Event Markers */}
                <div className="absolute inset-0">
                  <div
                    className="absolute top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-red-500 shadow-lg shadow-red-500/50"
                    style={{ left: '85%' }}
                    title="Strike Event"
                  ></div>
                  <div
                    className="absolute top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-amber-500 shadow-lg shadow-amber-500/50"
                    style={{ left: '65%' }}
                    title="Clash Event"
                  ></div>
                  <div
                    className="absolute top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-blue-500 shadow-lg shadow-blue-500/50"
                    style={{ left: '45%' }}
                    title="Movement Event"
                  ></div>
                </div>

                {/* Scrubber Handle */}
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={currentPosition}
                  onChange={handleScrubberChange}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
                <div
                  className="absolute top-1/2 -translate-y-1/2 w-4 h-4 bg-white border-2 border-slate-700 rounded-full shadow-lg pointer-events-none z-20"
                  style={{ left: `calc(${currentPosition}% - 8px)` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Status Info */}
          <div className="flex items-center gap-4 ml-4">
            <div className="px-3 py-1.5 bg-slate-800/50 border border-slate-700 rounded">
              <span className="text-xs font-mono text-cyan-400 font-bold">
                {getCurrentTime()} UTC
              </span>
            </div>
            <div className="px-3 py-1.5 bg-red-500/10 border border-red-500/30 rounded">
              <span className="text-xs font-bold text-red-400 uppercase tracking-wider">
                Strike: 1 SKL Unconfirmed
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
