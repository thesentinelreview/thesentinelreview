import { Layers } from 'lucide-react';

export function MapLegend() {
  return (
    <div className="absolute bottom-6 left-6 bg-slate-950/95 border border-slate-700 rounded-lg p-3 backdrop-blur-lg shadow-2xl">
      <div className="flex items-center gap-1.5 mb-2.5">
        <Layers className="w-3 h-3 text-slate-500" />
        <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Legend</h3>
      </div>

      <div className="space-y-2">
        <div className="flex items-center gap-2.5">
          <div className="w-4 h-4 rounded-full bg-red-500 shadow-lg shadow-red-500/30 shrink-0" />
          <span className="text-[11px] text-slate-400">Strike</span>
        </div>
        <div className="flex items-center gap-2.5">
          <div className="w-4 h-4 rounded-full bg-yellow-400 shadow-lg shadow-yellow-400/30 shrink-0" />
          <span className="text-[11px] text-slate-400">Clash</span>
        </div>
        <div className="flex items-center gap-2.5">
          <div className="w-4 h-4 rounded-full bg-blue-500 shadow-lg shadow-blue-500/30 shrink-0" />
          <span className="text-[11px] text-slate-400">Movement</span>
        </div>
      </div>
    </div>
  );
}
