import { Circle } from 'lucide-react';

interface Sensor {
  id: string;
  label: string;
  status: 'active' | 'inactive';
}

const sensors: Sensor[] = [
  { id: 'tg', label: 'TG', status: 'active' },
  { id: 'x', label: 'X', status: 'active' },
  { id: 'rss', label: 'RSS', status: 'active' },
  { id: 'gdelt', label: 'GDELT', status: 'active' },
  { id: 'bsky', label: 'BSKY', status: 'active' }
];

export function SensorStrip() {
  return (
    <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-slate-950 border-b border-amber-500/10">
      <div className="px-6 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            {sensors.map((sensor) => (
              <div
                key={sensor.id}
                className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800/40 border border-slate-700/50 rounded hover:border-slate-600 transition-colors"
              >
                <Circle
                  className={`w-2 h-2 ${
                    sensor.status === 'active' ? 'text-emerald-400 fill-emerald-400' : 'text-slate-600'
                  }`}
                />
                <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
                  {sensor.label}
                </span>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-4 text-xs">
            <div className="flex items-center gap-2 px-3 py-1 bg-slate-800/40 border border-slate-700/50 rounded">
              <span className="text-slate-500 font-semibold uppercase tracking-wider">LAT</span>
              <span className="text-cyan-400 font-mono font-bold">52m</span>
            </div>
            <div className="flex items-center gap-2 px-3 py-1 bg-slate-800/40 border border-slate-700/50 rounded">
              <span className="text-amber-400 font-mono font-bold">19</span>
              <span className="text-slate-500 font-semibold uppercase tracking-wider">TRK</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
