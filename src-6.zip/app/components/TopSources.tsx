import { Radio, CheckCircle2, Award, TrendingUp } from 'lucide-react';
import { Source } from '../data/mockData';

interface TopSourcesProps {
  sources: Source[];
}

const platformBadges = {
  RSS: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  X: 'bg-sky-500/20 text-sky-400 border-sky-500/30',
  Telegram: 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30',
  Wire: 'bg-purple-500/20 text-purple-400 border-purple-500/30'
};

export function TopSources({ sources }: TopSourcesProps) {
  return (
    <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <div className="p-1.5 bg-cyan-500/10 rounded-lg border border-cyan-500/20">
            <Radio className="w-4 h-4 text-cyan-400" />
          </div>
          Top Sources
        </h2>
        <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800/50 border border-slate-700 rounded-full">
          <TrendingUp className="w-3 h-3 text-emerald-400" />
          <span className="text-xs text-slate-400">30 Days</span>
        </div>
      </div>

      <div className="space-y-2.5">
        {sources.map((source, index) => (
          <div
            key={source.name}
            className="relative group bg-slate-800/40 border border-slate-700/50 rounded-lg p-3.5 hover:border-slate-600 hover:bg-slate-800/60 transition-all"
          >
            {index === 0 && (
              <div className="absolute -top-2 -left-2 p-1.5 bg-amber-500 rounded-full shadow-lg">
                <Award className="w-3 h-3 text-white" />
              </div>
            )}

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3 flex-1">
                <div className={`flex items-center justify-center w-7 h-7 rounded-lg font-bold text-sm ${
                  index === 0 ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                  index === 1 ? 'bg-slate-600/20 text-slate-400 border border-slate-600/30' :
                  index === 2 ? 'bg-orange-600/20 text-orange-400 border border-orange-600/30' :
                  'bg-slate-700/20 text-slate-500 border border-slate-700/30'
                }`}>
                  {index + 1}
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-slate-100 text-sm">{source.name}</span>
                    <span className={`px-2 py-0.5 rounded border text-[10px] font-semibold ${platformBadges[source.platform]}`}>
                      {source.platform}
                    </span>
                    {source.tier === 1 && (
                      <div className="flex items-center gap-1 px-1.5 py-0.5 bg-emerald-500/10 border border-emerald-500/20 rounded">
                        <CheckCircle2 className="w-2.5 h-2.5 text-emerald-400" />
                        <span className="text-[9px] text-emerald-400 font-semibold">T1</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-500">
                    <span>{source.eventCount} events</span>
                    <span>•</span>
                    <span>Tier {source.tier}</span>
                  </div>
                </div>
              </div>

              <div className="text-right">
                <div className={`text-xl font-bold ${
                  source.verificationRate >= 85 ? 'text-emerald-400' :
                  source.verificationRate >= 70 ? 'text-amber-400' :
                  'text-slate-400'
                }`}>
                  {source.verificationRate}%
                </div>
                <div className="text-[10px] text-slate-500 uppercase tracking-wider font-semibold">verified</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-5 pt-4 border-t border-slate-800">
        <p className="text-xs text-slate-500 leading-relaxed">
          <span className="text-slate-400 font-semibold">Verification rate:</span> Percentage of events later confirmed by independent sources
        </p>
      </div>
    </div>
  );
}
