import { FileText, Calendar, CheckCircle, Sparkles } from 'lucide-react';

interface DailyBriefingProps {
  briefing: {
    date: string;
    status: 'draft' | 'published';
    content: string;
    verifiedEventCount: number;
    partialEventCount: number;
    unconfirmedEventCount: number;
  };
}

export function DailyBriefing({ briefing }: DailyBriefingProps) {
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  // Convert markdown-style content to React elements
  const renderContent = (content: string) => {
    return content.split('\n\n').map((paragraph, index) => {
      if (paragraph.startsWith('**') && paragraph.includes('**')) {
        // Bold headers
        const text = paragraph.replace(/\*\*/g, '');
        return (
          <h3 key={index} className="text-base font-bold text-slate-100 mb-3 flex items-center gap-2">
            <div className="w-1 h-5 bg-blue-500 rounded"></div>
            {text}
          </h3>
        );
      }
      return (
        <p key={index} className="text-sm text-slate-300 leading-relaxed mb-4 pl-3">
          {paragraph}
        </p>
      );
    });
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-8 shadow-xl">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2 mb-2">
            <div className="p-1.5 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <FileText className="w-5 h-5 text-blue-400" />
            </div>
            Daily Intelligence Briefing
          </h2>
          <div className="flex items-center gap-3 text-sm">
            <div className="flex items-center gap-2 text-slate-400">
              <Calendar className="w-4 h-4" />
              {formatDate(briefing.date)}
            </div>
            <span className="text-slate-600">•</span>
            <div className="flex items-center gap-1.5 px-2 py-0.5 bg-purple-500/10 border border-purple-500/20 rounded text-purple-400">
              <Sparkles className="w-3 h-3" />
              <span className="text-xs font-semibold">AI-Generated</span>
            </div>
          </div>
        </div>

        {briefing.status === 'published' && (
          <div className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 text-sm font-semibold shadow-lg shadow-emerald-500/10">
            <CheckCircle className="w-4 h-4" />
            Published
          </div>
        )}
      </div>

      <div className="bg-slate-800/30 border border-slate-700/50 rounded-lg p-6 mb-6">
        {renderContent(briefing.content)}
      </div>

      <div className="flex items-center justify-between pt-5 border-t border-slate-800">
        <div className="flex items-center gap-6 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-emerald-400 shadow-lg shadow-emerald-400/30"></div>
            <span className="text-slate-400 font-medium">{briefing.verifiedEventCount} Verified</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-amber-400 shadow-lg shadow-amber-400/30"></div>
            <span className="text-slate-400 font-medium">{briefing.partialEventCount} Partial</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-slate-400"></div>
            <span className="text-slate-400 font-medium">{briefing.unconfirmedEventCount} Unconfirmed</span>
          </div>
        </div>

        <div className="text-xs text-slate-500">
          Generated at 06:00 UTC • Reviewed by editorial team
        </div>
      </div>
    </div>
  );
}
