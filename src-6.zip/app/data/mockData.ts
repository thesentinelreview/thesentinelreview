// Mock data for the Sentinel Review Intel Dashboard

export interface ConflictEvent {
  id: string;
  type: 'strike' | 'clash' | 'movement';
  confidence: 'verified' | 'partial' | 'unconfirmed';
  location: string;
  oblast: string;
  coordinates: [number, number]; // [lng, lat]
  timestamp: string;
  description: string;
  actingForce?: string;
  sources: string[];
}

export interface Source {
  name: string;
  platform: 'RSS' | 'X' | 'Telegram' | 'Wire';
  tier: 1 | 2 | 3;
  verificationRate: number;
  eventCount: number;
}

export interface DailyStats {
  date: string;
  eventCount: number;
  strikeCount: number;
}

export const conflictEvents: ConflictEvent[] = [
  {
    id: 'evt_001',
    type: 'strike',
    confidence: 'verified',
    location: 'Bakhmut',
    oblast: 'Donetsk',
    coordinates: [38.0000, 48.5959],
    timestamp: '2026-05-10T12:30:00Z',
    description: 'Artillery strike reported in eastern district. Multiple independent sources confirm impact.',
    actingForce: 'Russian Armed Forces',
    sources: ['DefMon3', 'Reuters', 'DeepStateUA']
  },
  {
    id: 'evt_002',
    type: 'clash',
    confidence: 'partial',
    location: 'Avdiivka',
    oblast: 'Donetsk',
    coordinates: [37.7500, 48.1400],
    timestamp: '2026-05-10T10:15:00Z',
    description: 'Ground engagement near industrial zone. Confirmed by regional press and military channels.',
    sources: ['Militaryland', 'Kyiv Independent']
  },
  {
    id: 'evt_003',
    type: 'movement',
    confidence: 'verified',
    location: 'Kupiansk',
    oblast: 'Kharkiv',
    coordinates: [37.6130, 49.7100],
    timestamp: '2026-05-10T08:45:00Z',
    description: 'Convoy movement observed via satellite imagery. Geolocated footage confirms northbound route.',
    actingForce: 'Ukrainian Armed Forces',
    sources: ['GeoConfirmed', 'OSINTtechnical', 'AFP']
  },
  {
    id: 'evt_004',
    type: 'strike',
    confidence: 'verified',
    location: 'Mariupol',
    oblast: 'Donetsk',
    coordinates: [37.5430, 47.0970],
    timestamp: '2026-05-10T06:20:00Z',
    description: 'Missile impact on port infrastructure. Official acknowledgment and press coverage.',
    sources: ['Reuters', 'AP', 'UAWeapons']
  },
  {
    id: 'evt_005',
    type: 'clash',
    confidence: 'unconfirmed',
    location: 'Vovchansk',
    oblast: 'Kharkiv',
    coordinates: [36.9430, 50.2880],
    timestamp: '2026-05-09T22:10:00Z',
    description: 'Reported skirmish near border checkpoint. Single source, awaiting corroboration.',
    sources: ['Rybar']
  },
  {
    id: 'evt_006',
    type: 'strike',
    confidence: 'partial',
    location: 'Zaporizhzhia',
    oblast: 'Zaporizhzhia',
    coordinates: [35.1396, 47.8388],
    timestamp: '2026-05-09T18:30:00Z',
    description: 'Air defense engagement reported. Multiple sources on same platform confirm activity.',
    sources: ['UkraineWarReport', 'DeepStateUA']
  },
  {
    id: 'evt_007',
    type: 'movement',
    confidence: 'partial',
    location: 'Lyman',
    oblast: 'Donetsk',
    coordinates: [37.8000, 48.9850],
    timestamp: '2026-05-09T15:00:00Z',
    description: 'Troop repositioning observed. Tier 2 source with corroborating signal.',
    sources: ['Militaryland']
  },
  {
    id: 'evt_008',
    type: 'strike',
    confidence: 'verified',
    location: 'Severodonetsk',
    oblast: 'Luhansk',
    coordinates: [38.4914, 48.9480],
    timestamp: '2026-05-09T12:45:00Z',
    description: 'Precision strike on ammunition depot. Geolocated footage and official reports.',
    actingForce: 'Ukrainian Armed Forces',
    sources: ['DefMon3', 'GeoConfirmed', 'Defense News']
  }
];

export const topSources: Source[] = [
  { name: 'DefMon3', platform: 'X', tier: 1, verificationRate: 87, eventCount: 142 },
  { name: 'GeoConfirmed', platform: 'X', tier: 1, verificationRate: 91, eventCount: 128 },
  { name: 'Reuters', platform: 'RSS', tier: 1, verificationRate: 95, eventCount: 89 },
  { name: 'DeepStateUA', platform: 'Telegram', tier: 2, verificationRate: 73, eventCount: 201 },
  { name: 'Militaryland', platform: 'Telegram', tier: 2, verificationRate: 68, eventCount: 156 },
  { name: 'AP', platform: 'RSS', tier: 1, verificationRate: 93, eventCount: 76 }
];

export const weeklyStats: DailyStats[] = [
  { date: '2026-05-04', eventCount: 45, strikeCount: 28 },
  { date: '2026-05-05', eventCount: 52, strikeCount: 31 },
  { date: '2026-05-06', eventCount: 38, strikeCount: 22 },
  { date: '2026-05-07', eventCount: 67, strikeCount: 42 },
  { date: '2026-05-08', eventCount: 41, strikeCount: 25 },
  { date: '2026-05-09', eventCount: 55, strikeCount: 33 },
  { date: '2026-05-10', eventCount: 48, strikeCount: 29 }
];

export const dailyBriefing = {
  date: '2026-05-10',
  status: 'published' as const,
  content: `**Theater Summary — 10 May 2026, 06:00 UTC**

Activity across the Donetsk and Kharkiv oblasts remains consistent with the 7-day baseline, recording 48 discrete events in the past 24 hours. Strike activity concentrated in the Bakhmut sector (verified: artillery impact on eastern district, 12:30 UTC) and Mariupol port infrastructure (verified: missile strike, 06:20 UTC). Ground engagements continue near Avdiivka industrial zone (partial confidence).

Northern sectors show increased logistical movement: geolocated convoy footage confirms Ukrainian repositioning near Kupiansk (verified, 08:45 UTC). Zaporizhzhia air defense engagement reported by multiple Telegram channels (partial confidence). Unconfirmed border activity near Vovchansk requires additional sourcing before assessment.

**Watch:** Monitor Severodonetsk ammunition depot strike aftermath (verified 09 May, 12:45 UTC) for potential escalation indicators in Luhansk oblast over next 24 hours.`,
  verifiedEventCount: 4,
  partialEventCount: 3,
  unconfirmedEventCount: 1
};
