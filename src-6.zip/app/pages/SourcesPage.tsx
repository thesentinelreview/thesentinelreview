import { Header } from '../components/Header';
import { SensorStrip } from '../components/SensorStrip';
import { SourceFeed } from '../components/SourceFeed';

export function SourcesPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header />
      <SensorStrip />
      <SourceFeed />
    </div>
  );
}
