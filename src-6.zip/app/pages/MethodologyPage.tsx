import { Header } from '../components/Header';
import { SensorStrip } from '../components/SensorStrip';
import { ShieldCheck, ShieldAlert, AlertTriangle, FileText, Layers, GitMerge, Eye, UserCheck, AlertCircle } from 'lucide-react';

export function MethodologyPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header />
      <SensorStrip />

      <main className="p-6 max-w-4xl mx-auto space-y-6">

        {/* Page title */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-1.5 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <FileText className="w-4 h-4 text-blue-400" />
            </div>
            <h1 className="text-lg font-bold text-slate-100">Verification Methodology</h1>
          </div>
          <p className="text-sm text-slate-400 leading-relaxed">
            How Sentinel collects, evaluates, and publishes conflict event data — including source weighting, confidence scoring, and editorial standards.
          </p>
        </div>

        {/* Confidence Levels */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
          <div className="flex items-center gap-2 mb-5">
            <div className="p-1.5 bg-emerald-500/10 rounded-lg border border-emerald-500/20">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
            </div>
            <h2 className="text-base font-bold text-slate-100 uppercase tracking-wider">Confidence Levels</h2>
          </div>

          <div className="space-y-3">
            {/* Verified */}
            <div className="bg-slate-800/40 border border-emerald-500/20 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/15 border border-emerald-500/30 rounded-full">
                  <ShieldCheck className="w-3 h-3 text-emerald-400" />
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">Verified</span>
                </div>
              </div>
              <p className="text-sm text-slate-300 leading-relaxed">
                The event is corroborated by at least two independent sources from different platforms or organisations, and at least one of the following: geolocated footage, official acknowledgement, or matching local press wire.
              </p>
              <div className="mt-2 text-xs text-slate-500 font-mono">
                → geolocated OR officially corroborated OR wire-matched
              </div>
            </div>

            {/* Partial */}
            <div className="bg-slate-800/40 border border-amber-500/20 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-500/15 border border-amber-500/30 rounded-full">
                  <ShieldAlert className="w-3 h-3 text-amber-400" />
                  <span className="text-xs font-bold text-amber-400 uppercase tracking-wider">Partial</span>
                </div>
              </div>
              <p className="text-sm text-slate-300 leading-relaxed">
                Multiple sources report the event from the same platform, or a single source with corroborating signal. The event likely occurred, but the precise location or scale remains unconfirmed.
              </p>
              <div className="mt-2 text-xs text-slate-500 font-mono">
                → single platform cross-referenced OR one source + signal
              </div>
            </div>

            {/* Unconfirmed */}
            <div className="bg-slate-800/40 border border-slate-600/30 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-2">
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-700/50 border border-slate-600/50 rounded-full">
                  <AlertTriangle className="w-3 h-3 text-slate-400" />
                  <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Unconfirmed</span>
                </div>
              </div>
              <p className="text-sm text-slate-300 leading-relaxed">
                A single source, or multiple sources along the same Telegram channel. Included for situational awareness but not yet verified. May be updated or removed if disputed.
              </p>
              <div className="mt-2 text-xs text-slate-500 font-mono">
                → single source OR single-channel cluster, no corroboration
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-slate-800/60">
            <p className="text-xs text-slate-500 leading-relaxed">
              <span className="text-amber-400/80 font-semibold">Note:</span> Confidence can only go down, not up, once a credible dispute has been filed. See Errors & Corrections below.
            </p>
          </div>
        </div>

        {/* Source Trust Tiers */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
          <div className="flex items-center gap-2 mb-5">
            <div className="p-1.5 bg-amber-500/10 rounded-lg border border-amber-500/20">
              <Layers className="w-4 h-4 text-amber-400" />
            </div>
            <h2 className="text-base font-bold text-slate-100 uppercase tracking-wider">Source Trust Tiers</h2>
          </div>
          <p className="text-sm text-slate-400 mb-4 leading-relaxed">
            Every source is assigned a trust tier by internal review. Tiers affect how much weight a source's posts receive in confidence scoring — a Tier 1 source reaching verified confidence score is proportionally stronger than a Tier 3 surrounding them.
          </p>

          <div className="space-y-3">
            <div className="bg-slate-800/40 border border-emerald-500/20 rounded-lg p-4">
              <div className="flex items-center gap-3 mb-2">
                <span className="px-2 py-0.5 bg-emerald-500/15 border border-emerald-500/30 rounded text-xs font-bold text-emerald-400 uppercase tracking-wider">Tier 1</span>
                <span className="text-sm font-semibold text-slate-200">High trust</span>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed">
                Established media organisations with documented track records and formal editorial standards. Includes wire services, AFP, AP, Ukrpravda, and major regional outlets with explicit correction policies and named reporters.
              </p>
            </div>

            <div className="bg-slate-800/40 border border-amber-500/20 rounded-lg p-4">
              <div className="flex items-center gap-3 mb-2">
                <span className="px-2 py-0.5 bg-amber-500/15 border border-amber-500/30 rounded text-xs font-bold text-amber-400 uppercase tracking-wider">Tier 2</span>
                <span className="text-sm font-semibold text-slate-200">Medium trust</span>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed">
                Known conflict-monitoring accounts and aggregators with a demonstrated methodology, regular error correction, and community validation. Includes deep-state maps, regional military bloggers with verified geolocations.
              </p>
            </div>

            <div className="bg-slate-800/40 border border-slate-600/30 rounded-lg p-4">
              <div className="flex items-center gap-3 mb-2">
                <span className="px-2 py-0.5 bg-slate-700/50 border border-slate-600/50 rounded text-xs font-bold text-slate-400 uppercase tracking-wider">Tier 3</span>
                <span className="text-sm font-semibold text-slate-200">Low trust</span>
              </div>
              <p className="text-sm text-slate-400 leading-relaxed">
                Anonymous accounts, single-instance sources, or multiple sources along the same Telegram channel. Posts from Tier 3 sources require independent corroboration before reaching Partial confidence. Never count alone.
              </p>
            </div>
          </div>
        </div>

        {/* Event Processing Pipeline */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
          <div className="flex items-center gap-2 mb-5">
            <div className="p-1.5 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <GitMerge className="w-4 h-4 text-blue-400" />
            </div>
            <h2 className="text-base font-bold text-slate-100 uppercase tracking-wider">Event Processing Pipeline</h2>
          </div>

          <div className="space-y-3">
            {[
              {
                step: '01',
                label: 'Ingestion',
                icon: <Eye className="w-3.5 h-3.5 text-blue-400" />,
                color: 'border-blue-500/20 bg-blue-500/5',
                desc: 'Posts are collected from curated source feeds: RSS, Telegram channels, X/Twitter, and GDELT at regular intervals. From archive to ingest: approximately 15–30 minutes, depending on source.'
              },
              {
                step: '02',
                label: 'Entity extraction',
                icon: <Layers className="w-3.5 h-3.5 text-purple-400" />,
                color: 'border-purple-500/20 bg-purple-500/5',
                desc: 'Named entities, locations, and event types are extracted automatically. Location strings are resolved against a gazetteer of Ukrainian oblasts, settlements, and front-line grid references.'
              },
              {
                step: '03',
                label: 'Deduplication and clustering',
                icon: <GitMerge className="w-3.5 h-3.5 text-cyan-400" />,
                color: 'border-cyan-500/20 bg-cyan-500/5',
                desc: 'Similar events within a 6-hour window are clustered by location and type. A single event may draw from 2–20 source posts. From archive to display: typically under 45 minutes with significant traction.'
              },
              {
                step: '04',
                label: 'Confidence scoring',
                icon: <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />,
                color: 'border-emerald-500/20 bg-emerald-500/5',
                desc: 'Each cluster receives a confidence score based on source tier, corroboration count, and geolocation availability. Scores map to Unconfirmed / Partial / Verified thresholds documented above.'
              },
              {
                step: '05',
                label: 'Human review queue',
                icon: <UserCheck className="w-3.5 h-3.5 text-amber-400" />,
                color: 'border-amber-500/20 bg-amber-500/5',
                desc: 'High-impact events (casualty reports, infrastructure strikes, front-line changes) are flagged for editorial review before publication. Editors may adjust confidence, merge duplicates, or suppress a cluster entirely.'
              }
            ].map(({ step, label, icon, color, desc }) => (
              <div key={step} className={`border ${color} rounded-lg p-4`}>
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-[10px] font-bold text-slate-600 font-mono">{step}</span>
                  <div className="flex items-center gap-1.5">
                    {icon}
                    <span className="text-sm font-semibold text-slate-200">{label}</span>
                  </div>
                </div>
                <p className="text-sm text-slate-400 leading-relaxed pl-6">{desc}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Errors and Corrections */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
          <div className="flex items-center gap-2 mb-5">
            <div className="p-1.5 bg-red-500/10 rounded-lg border border-red-500/20">
              <AlertCircle className="w-4 h-4 text-red-400" />
            </div>
            <h2 className="text-base font-bold text-slate-100 uppercase tracking-wider">Errors and Corrections</h2>
          </div>

          <div className="space-y-4 text-sm text-slate-300 leading-relaxed">
            <p>
              <span className="font-semibold text-slate-100">Every event page has a "Report this event" link.</span> If you believe an event is incorrectly located, mislabeled, or based on fabricated sources, use that link. Reports go directly to the editorial queue and are reviewed within 24 hours.
            </p>
            <p className="text-slate-400">
              Corrections are published openly in the event's change history. Confidence can only go down, not up, once a credible dispute has been filed.
            </p>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-800/60">
            <p className="text-[11px] text-slate-600 uppercase tracking-widest font-mono">
              To report an event error: use the "Report" link on the event page, or email{' '}
              <a href="mailto:corrections@thesentinelreview.com" className="text-slate-500 hover:text-slate-300 underline underline-offset-2 transition-colors">
                corrections@thesentinelreview.com
              </a>
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-slate-700 pb-6">
          <p>The Sentinel Review — Washington, D.C.</p>
          <p className="mt-1">contact@thesentinelreview.com · thesentinelreview.com</p>
        </div>

      </main>
    </div>
  );
}
