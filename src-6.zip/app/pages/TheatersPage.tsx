import { Header } from '../components/Header';
import { SensorStrip } from '../components/SensorStrip';
import { ArrowRight, Globe } from 'lucide-react';

interface Theater {
  id: string;
  name: string;
  description: string;
  events24h: number;
  verifiedPct: number;
  active: boolean;
  hash: string;
}

const theaters: Theater[] = [
  {
    id: 'ukraine',
    name: 'Ukraine',
    description: 'Eastern theater — Donetsk and Luhansk axes, strikes and ground contact.',
    events24h: 48,
    verifiedPct: 2,
    active: true,
    hash: '#theater-ukraine'
  },
  {
    id: 'iran',
    name: 'Iran',
    description: 'Iran proper, Israel–Iran exchanges, and proxy activity across the region.',
    events24h: 24,
    verifiedPct: 0,
    active: true,
    hash: '#theater-iran'
  },
  {
    id: 'sudan',
    name: 'Sudan',
    description: 'SAF vs RSF civil war — Khartoum, Darfur, and Kordofan axes.',
    events24h: 4,
    verifiedPct: 0,
    active: true,
    hash: '#theater-sudan'
  },
  {
    id: 'myanmar',
    name: 'Myanmar',
    description: 'Junta vs PDF and EAOs — Sagaing, Shan, Kayin, Chin, Rakhine.',
    events24h: 2,
    verifiedPct: 0,
    active: true,
    hash: '#theater-myanmar'
  }
];

export function TheatersPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header />
      <SensorStrip />

      <main className="p-6 max-w-[1800px] mx-auto">

        {/* Page header */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-1.5 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <Globe className="w-4 h-4 text-blue-400" />
            </div>
            <h2 className="text-lg font-bold text-slate-100">Theaters</h2>
          </div>
          <p className="text-sm text-slate-500 font-mono">
            Live OSINT conflict coverage across four active theaters. Updated every 30 minutes.
          </p>
        </div>

        {/* 2×2 grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {theaters.map(theater => (
            <a
              key={theater.id}
              href={theater.hash}
              className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl hover:border-slate-500 hover:bg-slate-800/60 transition-all group block"
            >
              <div className="flex items-start justify-between mb-3">
                <h3 className="text-base font-bold text-slate-100 uppercase tracking-widest">
                  {theater.name}
                </h3>
                <ArrowRight className="w-4 h-4 text-slate-600 group-hover:text-slate-400 group-hover:translate-x-1 transition-all shrink-0 mt-0.5" />
              </div>

              <p className="text-sm text-slate-400 leading-relaxed mb-6">
                {theater.description}
              </p>

              <div className="border-t border-slate-800/60 pt-4 grid grid-cols-2 gap-6">
                <div>
                  <div className="text-[10px] font-bold text-slate-600 uppercase tracking-widest mb-1">
                    Events 24H
                  </div>
                  <div className="text-2xl font-bold text-slate-100 tabular-nums">
                    {theater.events24h}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] font-bold text-slate-600 uppercase tracking-widest mb-1">
                    Verified
                  </div>
                  <div className="text-2xl font-bold text-slate-100 tabular-nums">
                    {theater.verifiedPct}
                    <span className="text-sm font-semibold text-slate-500 ml-0.5">%</span>
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>

        {/* Footer disclaimer */}
        <div className="mt-8 text-center">
          <p className="text-[11px] text-slate-700 font-mono">
            AI-generated analysis. Events sourced from open-source reporting; locations and details unverified. Not for operational use.
          </p>
        </div>

      </main>
    </div>
  );
}
