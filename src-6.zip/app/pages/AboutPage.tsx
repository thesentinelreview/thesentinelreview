import { Header } from '../components/Header';
import { SensorStrip } from '../components/SensorStrip';
import { Info } from 'lucide-react';

export function AboutPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header />
      <SensorStrip />

      <main className="p-6 max-w-4xl mx-auto space-y-6">

        {/* Page header */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-1.5 bg-blue-500/10 rounded-lg border border-blue-500/20">
              <Info className="w-4 h-4 text-blue-400" />
            </div>
            <h1 className="text-lg font-bold text-slate-100">About Sentinel Review</h1>
          </div>
          <p className="text-sm text-slate-400 leading-relaxed">
            A data-driven aggregation engine and intelligence dashboard for the OSINT community.
          </p>
        </div>

        {/* What This Is */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
          <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-5">What This Is</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <p className="text-sm text-slate-300 leading-relaxed">
                  Confidence-based event tracking across active conflict theaters, drawing from open-source intelligence: Telegram channels, wire RSS feeds, X/Twitter accounts, GDELT, and Bluesky. Every event is scored on a three-level confidence scale before publication.
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-400 leading-relaxed">
                  <span className="text-slate-200 font-semibold">v0.1 covers a single theater: Ukraine, eastern Ukraine.</span> The map focuses on the Donetsk and Luhansk axes, strikes and ground contact. Additional theaters (Iran, Sudan, Myanmar) are in limited data collection.
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-400 leading-relaxed">
                  Confidence levels are determined from source verification standards, not editorial opinion — a Verified event has corroboration from at least two independent sources with geolocation or official acknowledgement.
                </p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-slate-400 leading-relaxed">
                  Base map tiles from MapLibre GL with OpenStreetMap data. Event markers are placed at the centroid of the reported location — grid-level precision where geolocated footage is available, settlement-level otherwise.
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-400 leading-relaxed">
                  Every event links to its source materials. You can see exactly which posts drove the confidence score and read the original language text where AI translation was applied.
                </p>
              </div>
              <div>
                <p className="text-sm text-slate-400 leading-relaxed">
                  Annotations are published and source reports are preserved in the event's change history. If confidence changes, the record reflects that — we do not silently update or remove events.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* What This Is Not */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
          <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-5">What This Is Not</h2>
          <div className="space-y-3">
            {[
              'A real-time feed — events are processed and verified before appearing on the map.',
              'An authoritative record — it is an OSINT aggregation tool, not a primary source.',
              'Complete — only events that pass through the ingestion pipeline are shown. Many events go unreported by monitored sources.',
              'Impartial by design — sources have known editorial stances. Trust tiers and source attribution are our mitigations, not a guarantee of neutrality.',
              'A targeting or intelligence tool — we actively decline to build features that would support operational military use.',
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-3 bg-slate-800/40 border border-slate-700/50 rounded-lg px-4 py-3">
                <span className="text-red-500 font-bold text-sm shrink-0 mt-0.5">×</span>
                <p className="text-sm text-slate-300 leading-relaxed">{item}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Who Runs It */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl">
          <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Who Runs It</h2>
          <div className="space-y-3 text-sm text-slate-400 leading-relaxed">
            <p>
              Sentinel Review is an independent project run by{' '}
              <span className="text-slate-200 font-semibold">Jacob</span>. It has no institutional affiliation, no government funding, and no relationship with any military or intelligence organisation. The source code for the ingestion pipeline methodology is documented publicly at{' '}
              <a href="#methodology" className="text-blue-400 hover:text-blue-300 transition-colors">/methodology</a>.
            </p>
            <p>
              The product is free and public. Future tiers may add additional features for professional analysts, but the core map, briefings, and source data will remain free and openly accessible.
            </p>
          </div>
        </div>

        {/* Contact */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl overflow-hidden shadow-xl">
          <div className="px-6 py-4 border-b border-slate-700/60">
            <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Contact</h2>
          </div>
          <div className="divide-y divide-slate-800/60">
            {[
              { label: 'General',       value: 'hello@thesentinelreview.com',       href: 'mailto:hello@thesentinelreview.com' },
              { label: 'Corrections',   value: 'corrections@thesentinelreview.com', href: 'mailto:corrections@thesentinelreview.com' },
              { label: 'Source Tips',   value: 'sources@thesentinelreview.com',     href: 'mailto:sources@thesentinelreview.com' },
              { label: 'Press',         value: 'Use the general address above',     href: null },
            ].map(({ label, value, href }) => (
              <div key={label} className="flex items-center gap-8 px-6 py-4">
                <span className="text-[10px] font-bold text-slate-600 uppercase tracking-widest w-28 shrink-0">{label}</span>
                {href ? (
                  <a href={href} className="text-sm text-blue-400 hover:text-blue-300 font-mono transition-colors">{value}</a>
                ) : (
                  <span className="text-sm text-slate-500 font-mono">{value}</span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Version */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl overflow-hidden shadow-xl">
          <div className="px-6 py-4 border-b border-slate-700/60">
            <h2 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Version</h2>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 divide-x divide-y md:divide-y-0 divide-slate-800/60">
            {[
              { label: 'Product Version', value: 'v0.1 (MVP)' },
              { label: 'Theater',         value: 'Ukraine — Eastern' },
              { label: 'Sources Tracked', value: '8 active' },
              { label: 'Launched',        value: 'May 2026' },
            ].map(({ label, value }) => (
              <div key={label} className="px-6 py-5">
                <div className="text-[9px] font-bold text-slate-600 uppercase tracking-widest mb-1.5">{label}</div>
                <div className="text-sm font-semibold text-slate-200">{value}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center text-xs text-slate-700 pb-6">
          <p>The Sentinel Review — Washington, D.C. · thesentinelreview.com</p>
        </div>

      </main>
    </div>
  );
}
