import { Header } from '../components/Header';
import { SensorStrip } from '../components/SensorStrip';
import { ChevronRight, ExternalLink, Eye, EyeOff, ChevronDown, ChevronUp, ArrowRight } from 'lucide-react';
import { useState } from 'react';

interface Post {
  id: string;
  source: string;
  platform: 'RSS' | 'X' | 'Telegram' | 'GDELT';
  tier: 1 | 2 | 3;
  timestamp: string;
  content: string;
  originalLanguage?: string;
  originalContent?: string;
  url?: string;
}

const posts: Post[] = [
  {
    id: '1',
    source: 'Primort.ksher',
    platform: 'Telegram',
    tier: 2,
    timestamp: '14 min ago',
    content: 'War update: A Russian Project 22160 Sentinel-class patrol ship was struck near Nova Toffana, occupied Crimea. The ship was reportedly hit by a Ukrainian naval drone. Damage assessment ongoing; Russian sources have not confirmed.',
    url: '#'
  },
  {
    id: '2',
    source: 'Kyiv Independent',
    platform: 'RSS',
    tier: 1,
    timestamp: '38 min ago',
    content: "Ukraine's drone decision: \"Unprecedented in modern history\" — Ukraine destroys Russia's drone fleet at occupied Donetsk Airport. A decision was made to carry out systematic preemptive strikes that will disrupt enemy launches and reduce the number of enemy drones that will once again fly to attack kindergartens, high-rise buildings, and hospitals.",
    url: '#'
  },
  {
    id: '3',
    source: 'Nextstep',
    platform: 'RSS',
    tier: 1,
    timestamp: '1h ago',
    content: 'War update: 178 combat clashes. Intense fighting in Pokrovsk sector (34 clashes). 178 combat engagements were recorded along the frontlines as of 22:00 on Monday, with the heaviest fighting near Pokrovsk, where Ukrainian forces repelled 34 Russian assaults. Ukrainian forces and Russian invaders, with the most intense activity recorded near Pokrovsk.',
    url: '#'
  },
  {
    id: '4',
    source: 'DeepStateUA',
    platform: 'Telegram',
    tier: 2,
    timestamp: '2h ago',
    content: 'Confirmed advance near Toretsk direction. Russian forces made marginal gains (~200m) along the H-32 highway approach. Ukrainian defenders have established new defensive positions 400m to the west. Situation assessed as stable with localized pressure.',
    originalLanguage: 'uk',
    originalContent: 'Підтверджений наступ поблизу Торецького напрямку. Російські сили здійснили незначні просування (~200м) вздовж підходу до шосе Н-32.',
    url: '#'
  },
  {
    id: '5',
    source: 'GDELT',
    platform: 'GDELT',
    tier: 1,
    timestamp: '3h ago',
    content: 'Event cluster: 11 correlated reports of artillery exchange, Chasiv Yar sector. Avg tone: −4.7. Actor pair: RUS mil / UKR mil. Geo confidence: HIGH. 7 of 11 sources independently geolocated to grid 37UDB448.',
    url: '#'
  },
  {
    id: '6',
    source: 'Ukrinform',
    platform: 'RSS',
    tier: 1,
    timestamp: '4h ago',
    content: 'Ukrainian air defense intercepts 23 of 31 Shahed drones overnight. The Air Force reports successful interception of 23 Shahed-136/131 drones during a nighttime attack. Eight drones reached their targets, causing damage to infrastructure in Zaporizhzhia and Dnipropetrovsk oblasts.',
    url: '#'
  }
];

const PLATFORM_STYLES: Record<string, string> = {
  RSS:      'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
  X:        'text-sky-400 bg-sky-500/10 border-sky-500/30',
  Telegram: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
  GDELT:    'text-amber-400 bg-amber-500/10 border-amber-500/30',
};

const TIER_STYLES: Record<number, string> = {
  1: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
  2: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
  3: 'text-slate-400 bg-slate-700/30 border-slate-600/40',
};

const topSources = [
  { rank: '01', name: 'Ukrinform',       events: 14, verifiedPct: 10 },
  { rank: '02', name: 'GDELT',           events: 13, verifiedPct: 30 },
  { rank: '03', name: 'Interfax Ukraine', events: 10, verifiedPct: 27 },
  { rank: '04', name: 'Kyiv Independent', events:  5, verifiedPct: 23 },
  { rank: '05', name: 'OSINT Technical', events:  3, verifiedPct: 43 },
];

function PostCard({ post }: { post: Post }) {
  const [showOriginal, setShowOriginal] = useState(false);
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-5 shadow-xl hover:border-slate-600 transition-all">
      <div className="flex items-center gap-2.5 mb-3 flex-wrap">
        <span className="font-bold text-slate-100 text-sm">{post.source}</span>
        <span className={`px-1.5 py-0.5 border rounded text-[9px] font-bold uppercase tracking-wider ${PLATFORM_STYLES[post.platform]}`}>
          {post.platform}
        </span>
        <span className={`px-1.5 py-0.5 border rounded text-[9px] font-bold uppercase tracking-wider ${TIER_STYLES[post.tier]}`}>
          Tier {post.tier}
        </span>
        <span className="ml-auto text-xs text-slate-500 font-mono">{post.timestamp}</span>
      </div>

      <p className={`text-sm text-slate-300 leading-relaxed mb-3 ${!expanded ? 'line-clamp-3' : ''}`}>
        {showOriginal && post.originalContent ? post.originalContent : post.content}
      </p>

      <div className="flex items-center gap-4 pt-3 border-t border-slate-800/60">
        {post.url && (
          <a href={post.url} className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 transition-colors">
            <ExternalLink className="w-3 h-3" />
            view source
          </a>
        )}
        {post.originalLanguage && (
          <button
            onClick={() => setShowOriginal(v => !v)}
            className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800/50 hover:bg-slate-700/50 border border-slate-700 rounded text-xs text-slate-400 hover:text-slate-300 transition-colors"
          >
            {showOriginal ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
            {showOriginal ? 'Hide original' : 'Show original'}
          </button>
        )}
        {post.content.length > 200 && (
          <button onClick={() => setExpanded(v => !v)} className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-400 transition-colors">
            {expanded ? <><ChevronUp className="w-3 h-3" />Collapse</> : <><ChevronDown className="w-3 h-3" />Expand</>}
          </button>
        )}
      </div>
    </div>
  );
}

export function UkraineTheaterPage() {
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header />
      <SensorStrip />

      <main className="p-6 max-w-[1800px] mx-auto">

        {/* Hero header */}
        <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl mb-6">
          <div className="flex items-center gap-2 text-[10px] uppercase tracking-widest text-slate-600 mb-3">
            <a href="#theaters" className="hover:text-slate-400 transition-colors">Theaters</a>
            <ChevronRight className="w-3 h-3" />
            <span className="text-slate-400">Ukraine</span>
            <ChevronRight className="w-3 h-3" />
            <span>Donetsk / Luhansk</span>
          </div>
          <h1 className="text-2xl font-bold text-slate-100 uppercase tracking-widest mb-1">Ukraine Theater</h1>
          <p className="text-xs text-slate-500 uppercase tracking-widest font-semibold">
            Eastern Theater &nbsp;·&nbsp; Donetsk / Luhansk Oblasts
          </p>
        </div>

        {/* Two-column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_340px] gap-6">

          {/* Left — AI source feed */}
          <div className="space-y-4">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">AI Source Feed</span>
              <div className="flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></div>
                <span className="text-xs text-emerald-400 font-semibold">Live</span>
              </div>
            </div>
            {posts.map(post => <PostCard key={post.id} post={post} />)}
          </div>

          {/* Right — sidebar */}
          <div className="space-y-6">

            {/* Live Activity */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-5 shadow-xl">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-4">Live Activity</h3>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <div className="text-2xl font-bold text-slate-100 tabular-nums">49</div>
                  <div className="text-[9px] text-slate-600 uppercase tracking-widest mt-1">Events</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-100 tabular-nums">338</div>
                  <div className="text-[9px] text-slate-600 uppercase tracking-widest mt-1">Weekly posts</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-slate-100 tabular-nums">743</div>
                  <div className="text-[9px] text-slate-600 uppercase tracking-widest mt-1">Total tracked</div>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between text-[10px] text-slate-600 font-mono uppercase tracking-widest">
                <span>24h window</span>
                <span>Updated 2 min ago</span>
              </div>
            </div>

            {/* About */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-5 shadow-xl">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">About This Theater</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                The Sentinel Review Ukraine theater tracks the eastern front of the Russo-Ukrainian war, with a primary focus on Donetsk and Luhansk oblasts. Where frontline activity is concerned, we pull from Ukrainian and Russian-facing channels, regional press, OSINT geolocators, and GDELT generators, and cross-reference each event across independent sources before publishing.
              </p>
              <p className="text-xs text-slate-500 leading-relaxed mt-3">
                Coverage extends across the order-of-battle line of maintained Ukraine and adjacent Russian border regions across former entities and infrastructure since voice. We do not produce political analysis — events are presented as discrete, geolocated facts with confidence levels that reflect the corroboration we have.
              </p>
            </div>

            {/* Key Actors */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-5 shadow-xl">
              <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Key Actors</h3>
              <ul className="space-y-2">
                {[
                  'Armed Forces of Ukraine (AFU / ЗСУ)',
                  'Russian Armed Forces and affiliated units',
                  'Volunteer formations on both sides (e.g. International Legion, Wagner remnants)',
                  'Ukrainian regional military administrations (OVAs)'
                ].map((actor, i) => (
                  <li key={i} className="flex items-start gap-2.5 text-xs text-slate-400">
                    <span className="w-1 h-1 rounded-full bg-slate-600 shrink-0 mt-1.5"></span>
                    {actor}
                  </li>
                ))}
              </ul>
            </div>

            {/* Top Sources */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl overflow-hidden shadow-xl">
              <div className="px-5 py-4 border-b border-slate-700/60">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Top Sources (30-day verification rate)</h3>
              </div>
              <div className="divide-y divide-slate-800/60">
                {topSources.map(s => (
                  <div key={s.rank} className="flex items-center gap-3 px-5 py-3 hover:bg-slate-800/30 transition-colors">
                    <span className="text-[10px] text-slate-700 font-mono w-4 shrink-0">{s.rank}</span>
                    <span className="text-sm text-slate-300 flex-1">{s.name}</span>
                    <span className="text-xs text-slate-500 font-mono tabular-nums">{s.events} events</span>
                    <span className={`text-xs font-bold tabular-nums w-10 text-right ${
                      s.verifiedPct >= 35 ? 'text-emerald-400' : s.verifiedPct >= 20 ? 'text-amber-400' : 'text-slate-500'
                    }`}>{s.verifiedPct}%</span>
                  </div>
                ))}
              </div>
              <div className="px-5 py-3 border-t border-slate-700/60">
                <a href="#sources" className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 font-mono transition-colors">
                  See all sources <ArrowRight className="w-3 h-3" />
                </a>
              </div>
            </div>

          </div>
        </div>

        {/* Footer */}
        <div className="mt-8 text-center">
          <p className="text-[11px] text-slate-700 font-mono">
            AI-generated analysis. Events sourced from open-source reporting; locations and details unverified. Not for operational use.
          </p>
        </div>

      </main>
    </div>
  );
}
