import { useState } from 'react';
import { Radio, ExternalLink, Eye, EyeOff, AlertTriangle, ShieldCheck, ChevronDown, ChevronUp } from 'lucide-react';

interface SourcePost {
  id: string;
  source: string;
  platform: 'RSS' | 'X' | 'Telegram' | 'Bluesky' | 'GDELT';
  tier: 1 | 2 | 3;
  timestamp: string;
  content: string;
  originalLanguage?: string;
  originalContent?: string;
  verified: boolean;
  url?: string;
}

const mockPosts: SourcePost[] = [
  {
    id: '1',
    source: 'Kyiv Independent',
    platform: 'RSS',
    tier: 1,
    timestamp: '20 min ago',
    content: 'Explosions rock Kyiv in Russian strikes amid intelligence warnings of mass attack. Russia launched a large-scale aerial attack against Ukraine overnight on June 2, targeting Kyiv and cities across the country with missiles and drone fire. At least two people were killed and several injured in the capital.',
    verified: false,
    url: '#'
  },
  {
    id: '2',
    source: 'Nexus',
    platform: 'RSS',
    tier: 2,
    timestamp: '1h ago',
    content: "Kyiv braces for 'massive' Russian strike after Putin says Ukrainian attack on Sevastola dorm changed war's 'nature'. Russian President Vladimir Putin convened a meeting to discuss the investigation into Ukraine's attack on a college building in the city of Sevastola in the occupied Luhansk region.",
    verified: false,
    url: '#'
  },
  {
    id: '3',
    source: 'DeepStateUA',
    platform: 'Telegram',
    tier: 2,
    timestamp: '3h ago',
    content: "Enemy conducting massive strike drone attack! Danger across districts of the city. Air defense is operating in Kharkivska. Monitoring channels report potential launches from enemy territory. The enemy has launched attacks on public spaces. Recommended taking shelter during these attacks.",
    originalLanguage: 'uk',
    originalContent: 'Ворог проводить масований ударний дрон атаку! Небезпека по районах міста. Протиповітряна оборона працює в Харківській. Канали моніторингу повідомляють про потенційні пуски з ворожої території.',
    verified: false,
    url: '#'
  },
  {
    id: '4',
    source: 'Tov Report',
    platform: 'Telegram',
    tier: 3,
    timestamp: '4h ago',
    content: "Russian drone damages Nova Post's innovative terminal in Dnipro. As a result of a Russian drone strike in Dnipro, Nova Post's innovative parcel-terminal infrastructure was struck. Emergency services are on site. No casualties reported at this time.",
    verified: false,
    url: '#'
  },
  {
    id: '5',
    source: 'GDELT Project',
    platform: 'GDELT',
    tier: 1,
    timestamp: '6h ago',
    content: 'Event cluster detected: 14 correlated reports of artillery exchange near Chasiv Yar sector. Average tone score: -4.2. Primary actors: RUS mil / UKR mil. Geolocation confidence: HIGH. Source triangulation: 8 of 14 sources independently verified.',
    verified: true,
    url: '#'
  },
  {
    id: '6',
    source: 'war_monitor',
    platform: 'X',
    tier: 3,
    timestamp: '7h ago',
    content: 'Confirmed: Ukrainian forces repelled Russian assault near Avdiivka direction. Video geolocated to grid 37UDB. ~2 Russian IFVs destroyed. Source: multiple Telegram channels cross-referenced.',
    verified: false,
    url: '#'
  }
];

const PLATFORM_STYLES: Record<string, string> = {
  RSS: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
  X: 'text-sky-400 bg-sky-500/10 border-sky-500/30',
  Telegram: 'text-blue-400 bg-blue-500/10 border-blue-500/30',
  Bluesky: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
  GDELT: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
};

const TIER_STYLES: Record<number, string> = {
  1: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
  2: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
  3: 'text-slate-400 bg-slate-700/30 border-slate-600/50',
};

export function SourceFeed() {
  const [showOriginal, setShowOriginal] = useState<string | null>(null);
  const [expandedPost, setExpandedPost] = useState<string | null>(null);

  return (
    <div className="p-6 max-w-[1800px] mx-auto">
      {/* Page header card */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl p-6 shadow-xl mb-6">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="p-1.5 bg-blue-500/10 rounded-lg border border-blue-500/20">
                <Radio className="w-4 h-4 text-blue-400" />
              </div>
              <h2 className="text-lg font-bold text-slate-100">Source Feed</h2>
              <div className="flex items-center gap-1.5 px-2.5 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></div>
                <span className="text-xs text-emerald-400 font-semibold">Live</span>
              </div>
            </div>
            <p className="text-xs text-slate-500 uppercase tracking-widest font-semibold">
              Eastern Theater &nbsp;·&nbsp; Donetsk / Luhansk Oblasts
            </p>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="px-3 py-1.5 bg-slate-800/50 border border-slate-700/50 rounded-lg">
              <span className="text-slate-500 uppercase tracking-wider">Next ingest</span>
              <span className="text-cyan-400 font-mono ml-2">00:04:11</span>
            </div>
            <div className="px-3 py-1.5 bg-slate-800/50 border border-slate-700/50 rounded-lg">
              <span className="text-slate-500 uppercase tracking-wider">Sources</span>
              <span className="text-slate-200 font-semibold ml-2">5 active</span>
            </div>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-slate-800/60">
          <p className="text-xs text-slate-500 leading-relaxed">
            Raw, unverified source posts — not yet corroborated or geolocated by Sentinel. AI-translated where available;
            original-language text via the "Show original" toggle on each card. Sourced from open-source reporting.{' '}
            <span className="text-amber-400/80 font-semibold">Not for operational use.</span>
          </p>
        </div>
      </div>

      {/* Feed */}
      <div className="bg-gradient-to-br from-slate-900 to-slate-900/80 border border-slate-700 rounded-xl shadow-xl overflow-hidden">
        {/* Section label */}
        <div className="px-6 py-3 border-b border-slate-700/60 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Yesterday</span>
          <span className="text-xs text-slate-600 font-mono">{mockPosts.length} items</span>
        </div>

        <div className="divide-y divide-slate-800/60">
          {mockPosts.map((post, index) => (
            <div
              key={post.id}
              className="relative group p-5 hover:bg-slate-800/30 transition-all"
            >
              {index === 0 && (
                <div className="absolute top-3 right-3 px-2 py-0.5 bg-red-500 text-white text-[10px] font-bold rounded-full uppercase tracking-wider shadow-lg">
                  New
                </div>
              )}

              {/* Header row */}
              <div className="flex items-center gap-3 mb-3 pr-12">
                <span className="font-bold text-slate-100 text-sm">{post.source}</span>

                <span className={`px-2 py-0.5 border rounded text-[10px] font-semibold uppercase tracking-wider ${PLATFORM_STYLES[post.platform]}`}>
                  {post.platform}
                </span>

                <span className={`px-2 py-0.5 border rounded text-[10px] font-semibold uppercase tracking-wider ${TIER_STYLES[post.tier]}`}>
                  Tier {post.tier}
                </span>

                {post.verified && (
                  <div className="flex items-center gap-1 px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/30 rounded text-[10px] font-semibold text-emerald-400 uppercase tracking-wider">
                    <ShieldCheck className="w-3 h-3" />
                    Verified
                  </div>
                )}

                <span className="ml-auto text-xs text-slate-500 font-mono">{post.timestamp}</span>
              </div>

              {/* Content */}
              <p className={`text-sm text-slate-300 leading-relaxed mb-3 ${expandedPost !== post.id ? 'line-clamp-3' : ''}`}>
                {showOriginal === post.id && post.originalContent
                  ? post.originalContent
                  : post.content}
              </p>

              {/* Footer row */}
              <div className="flex items-center gap-4 pt-2 border-t border-slate-800/40">
                {post.url && (
                  <a
                    href={post.url}
                    className="flex items-center gap-1.5 text-xs text-slate-500 hover:text-slate-300 transition-colors"
                  >
                    <ExternalLink className="w-3 h-3" />
                    view source
                  </a>
                )}

                {post.originalLanguage && (
                  <button
                    onClick={() => setShowOriginal(showOriginal === post.id ? null : post.id)}
                    className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800/50 hover:bg-slate-700/50 border border-slate-700 rounded text-xs text-slate-400 hover:text-slate-300 transition-colors"
                  >
                    {showOriginal === post.id ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    {showOriginal === post.id ? 'Hide original' : 'Show original'}
                  </button>
                )}

                {post.content.length > 200 && (
                  <button
                    onClick={() => setExpandedPost(expandedPost === post.id ? null : post.id)}
                    className="flex items-center gap-1 text-xs text-slate-500 hover:text-slate-400 transition-colors"
                  >
                    {expandedPost === post.id
                      ? <><ChevronUp className="w-3 h-3" /> Collapse</>
                      : <><ChevronDown className="w-3 h-3" /> Expand</>}
                  </button>
                )}

                <div className="flex-1" />

                {!post.verified && (
                  <div className="flex items-center gap-1.5 px-2 py-0.5 bg-slate-800/50 border border-slate-700/50 rounded text-[10px] font-semibold text-slate-500 uppercase tracking-wider">
                    <AlertTriangle className="w-3 h-3" />
                    Unverified
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Load more */}
        <div className="px-6 py-4 border-t border-slate-700/60 bg-slate-900/30">
          <button className="flex items-center gap-2 px-5 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-600 hover:border-slate-500 rounded-lg text-sm text-slate-300 hover:text-slate-100 font-semibold uppercase tracking-wider transition-all">
            Load Older Posts
          </button>
        </div>
      </div>
    </div>
  );
}
